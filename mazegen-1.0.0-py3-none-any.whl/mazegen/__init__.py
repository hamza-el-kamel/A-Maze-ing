from .mazegen import MazeGenerator
from .mazegen import Cell

_=MazeGenerator
_=Cell